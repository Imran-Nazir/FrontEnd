import React, {useState} from 'react';
import {CreateRequest} from "../APIRequest/ApiRequest.js";
import {useNavigate} from "react-router-dom";


const ProductPage = () => {

    let [FormValue,SetFormValue]=useState({
        Img:"",
        ProductCode:"",
        ProductName:"",
        Qty:"",
        TotalPrice:"",
        UnitPrice:""
    })
    
    
    const inputOnChange = (key,value) => {
        SetFormValue(FormValue=>({
            ...FormValue,
            [key]:value
        }))
    }


    let navigate=useNavigate();

    const submit = async () => {
       let res=await CreateRequest(FormValue);
       navigate("/")

    }



    return (
        <div>
            <input value={FormValue.Img} onChange={(e)=>{inputOnChange('Img',e.target.value)}}  placeholder="Img URL"/><br/><br/>
            <input value={FormValue.ProductCode} onChange={(e)=>{inputOnChange('ProductCode',e.target.value)}}  placeholder="ProductCodeL"/><br/><br/>
            <input value={FormValue.ProductName} onChange={(e)=>{inputOnChange('ProductName',e.target.value)}}  placeholder="ProductName"/><br/><br/>
            <input value={FormValue.Qty} onChange={(e)=>{inputOnChange('Qty',e.target.value)}}  placeholder="Qty"/><br/><br/>
            <input value={FormValue.TotalPrice} onChange={(e)=>{inputOnChange('TotalPrice',e.target.value)}}  placeholder="TotalPriceL"/><br/><br/>
            <input value={FormValue.UnitPrice} onChange={(e)=>{inputOnChange('UnitPrice',e.target.value)}}  placeholder="UnitPrice"/><br/><br/>
            <button onClick={submit}>Submit</button>
        </div>
    );
};

export default ProductPage;