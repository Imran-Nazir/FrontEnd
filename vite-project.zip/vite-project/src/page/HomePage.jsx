import React, {useEffect, useState} from 'react';
import {ReadRequest} from "../APIRequest/ApiRequest.js";
const HomePage = () => {
    let [data,SetData]=useState([])


    useEffect(() => {

        (async ()=>{
            let res=await ReadRequest();
            SetData(res)
        })()


    }, []);


    return (
        <div>

            <ul>
                {data.map((item,i)=>{
                    return <li>{item['ProductName']}</li>
                })}
            </ul>
        </div>
    );
};

export default HomePage;